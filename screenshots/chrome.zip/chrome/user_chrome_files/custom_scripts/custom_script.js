// This script can be used, for example, to create buttons using CustomizableUI.createWidget

(async ({UrlbarSearchOneOffs} = ChromeUtils.importESModule("resource:///modules/UrlbarSearchOneOffs.sys.mjs")) => {
    var orig = UrlbarSearchOneOffs.prototype.handleSearchCommand;
    UrlbarSearchOneOffs.prototype.handleSearchCommand = function handleSearchCommand() {
        var e = arguments[0];
        Object.defineProperty(e, "shiftKey", {
            enumerable: true,
            configurable: true,
            writable: false,
            value: !e.shiftKey,
        });
        return orig.apply(this, arguments);
    };
})();

(async () => CustomizableUI.createWidget({
    id: "ucf-read-mail",
    label: "Читать почту",
    tooltiptext: "Открыть приложение для чтения почты",
    localized: false,
    defaultArea: CustomizableUI.AREA_NAVBAR,
    onCreated(btn) {
        btn.style.setProperty("list-style-image", `url("chrome://user_chrome_files/content/custom_scripts/svg/email.svg")`, "important");
    },
    onCommand(e) {
        var appFile = Cc["@mozilla.org/file/local;1"].createInstance(Ci.nsIFile);
        appFile.initWithPath("/usr/bin/thunderbird");
        if (!appFile.exists() || !appFile.isExecutable())
            return;
        var process = Cc["@mozilla.org/process/util;1"].createInstance(Ci.nsIProcess);
        process.init(appFile);
        process.runwAsync([], 0);
    },
}))();

/* ({
    async init() {
        const {LightweightThemeManager} = ChromeUtils.importESModule("resource://gre/modules/LightweightThemeManager.sys.mjs");
        this.update(LightweightThemeManager.themeData);
        Services.obs.addObserver(this, "lightweight-theme-styling-update");
    },
    observe(aSubject, aTopic, aData) {
        var obj = aSubject?.wrappedJSObject;
        if (typeof obj != "object") return;
        this.update(obj);
    },
    update(obj) {
        var theme = obj.theme;
        if (!theme || obj.darkTheme?.textcolor || !InspectorUtils.isValidCSSColor(theme.textcolor)) {
            if (Services.prefs.getPrefType("ui.systemUsesDarkTheme") == Services.prefs.PREF_INT)
                Services.prefs.clearUserPref("ui.systemUsesDarkTheme");
            return;
        }
        var {r, g, b} = InspectorUtils.colorToRGBA(theme.textcolor);
        Services.prefs.setIntPref("ui.systemUsesDarkTheme", this._isColorDark(r, g, b) ? 0 : 1);
    },
    _isColorDark(r, g, b) {
        return 0.2125 * r + 0.7154 * g + 0.0721 * b <= 127;
    },
}).init(); */
