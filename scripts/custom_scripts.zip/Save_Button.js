// Этот скрипт можно использовать для создания кнопок с помощью CustomizableUI.createWidget

// Кнопка Save - Основной скрипт в Save_Script.js
// Правка Vitaliy V.
// https://forum.mozilla-russia.org/viewtopic.php?pid=809376#p809376

(async () => CustomizableUI.createWidget({
	id: "ucf-cbbtn-Save",
	tooltiptext: "Сохранить страницу\n/ часть / выбранное",
	nameSaveScript: "Save_Script.js",
	localized: false,
	cbu: {
		types: {
			128: "Bool", boolean: "Bool",
			64: "Int", number: "Int",
			32: "String", string: "String"
		},
		getPrefs(pref) {
			try {
				return Services.prefs[`get${
					this.types[Services.prefs.getPrefType(pref)]
				}Pref`](pref);
			}
			catch {return null;}
		},
		setPrefs(pref, val) {
			Services.prefs[`set${this.types[typeof val]}Pref`](pref, val);
		}
	},
	gClipboard: {
		get ch() {
			delete this.ch;
			return this.ch = Cc["@mozilla.org/widget/clipboardhelper;1"]
				.getService(Ci.nsIClipboardHelper);
		},
		write(str) {
			this.ch.copyStringToClipboard(str, Services.clipboard.kGlobalClipboard);
		}
	},
	custombuttonsUtils: {
		writeFile(path, data) {
			try {
				if (path.includes(":\\")) path = path.replace(/\//g, "\\");
				var file = Cc["@mozilla.org/file/local;1"].createInstance(Ci.nsIFile);
				file.initWithPath(path);
				file.exists() && file.remove(false);

				var strm = Cc["@mozilla.org/network/file-output-stream;1"]
					.createInstance(Ci.nsIFileOutputStream);
				strm.init(file, 0x04 | 0x08, 420, 0);
				strm.write(data, data.length);
				strm.flush();
				strm.close();
			} catch(ex) {
				Cu.reportError("Custom Buttons: " + [path, "---", ex, ex.stack].join("\n"));
			}
		}
	},
	addDestructor(destructor, context) {
		this._destructors.push({destructor, context});
	},
	addEventListener(...args) {
		var trg = args[3];
		if (!trg) trg = args[3] = this.ownerGlobal;
		trg.addEventListener(...args);
		this._handlers.push(args);
	},

	onCreated(btn) {
		var win = btn.ownerGlobal;
		btn._handlers = new win.Array();
		btn._destructors = new win.Array();
		win.addEventListener("unload", this, {once: true});
		btn.self = btn;
		btn._id = this.id;
		btn.cbu = this.cbu;
		btn.xhtmlns = "http://www.w3.org/1999/xhtml";
		btn.addDestructor = this.addDestructor.bind(btn);
		btn.addEventListener = this.addEventListener.bind(btn);
		btn.gClipboard = this.gClipboard;
		btn.custombuttonsUtils = this.custombuttonsUtils;
		Services.scriptloader.loadSubScript(`chrome://user_chrome_files/content/custom_scripts/${this.nameSaveScript}`, btn);
		btn.setAttribute("image", this.image);
	},
	get image() {
		var img = `${this.id.toLowerCase()}-img`;
		Services.io.getProtocolHandler("resource")
			.QueryInterface(Ci.nsIResProtocolHandler)
			.setSubstitution(img, Services.io.newURI("data:image/svg+xml;base64,77u/PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0idXRmLTgiPz4NCjxzdmcgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB2aWV3Qm94PSIwIDAgMjYgMjYiIHdpZHRoPSIzMiIgaGVpZ2h0PSIzMiI+DQogIDxwYXRoIGQ9Ik0xOCA5TDE1IDlMMTUgMkwxOCAyIFogTSAyNiA2TDI2IDIzQzI2IDI0LjY1NjI1IDI0LjY1NjI1IDI2IDIzIDI2TDMgMjZDMS4zNDM3NSAyNiAwIDI0LjY1NjI1IDAgMjNMMCAzQzAgMS4zNDM3NSAxLjM0Mzc1IDAgMyAwTDIwIDBDMjAuODI4MTI1IDAgMjEuMjg1MTU2IDAuMDQyOTY4OCAyMy42MjEwOTQgMi4zNzg5MDZDMjUuOTU3MDMxIDQuNzE0ODQ0IDI2IDUuMTcxODc1IDI2IDYgWiBNIDUgOUM1IDkuNTUwNzgxIDUuNDQ5MjE5IDEwIDYgMTBMMTkgMTBDMTkuNTUwNzgxIDEwIDIwIDkuNTUwNzgxIDIwIDlMMjAgMkMyMCAxLjQ0OTIxOSAxOS41NTA3ODEgMSAxOSAxTDYgMUM1LjQ0OTIxOSAxIDUgMS40NDkyMTkgNSAyIFogTSAyMyAxNEMyMyAxMy40NDkyMTkgMjIuNTUwNzgxIDEzIDIyIDEzTDQgMTNDMy40NDkyMTkgMTMgMyAxMy40NDkyMTkgMyAxNEwzIDI0QzMgMjQuNTUwNzgxIDMuNDQ5MjE5IDI1IDQgMjVMMjIgMjVDMjIuNTUwNzgxIDI1IDIzIDI0LjU1MDc4MSAyMyAyNFoiIGZpbGw9IiM4RThFOTgiIC8+DQo8L3N2Zz4="));
			delete this.image;
			return this.image = `resource://${img}`;
	},
	handleEvent(e) {
		var btn = e.target.getElementById(this.id);
		for(var args of btn._handlers)
			args.pop().removeEventListener(...args);
		delete btn._handlers;
		for(var {destructor, context} of btn._destructors)
			try {destructor.call(context, "destructor");}
			catch(ex) {Cu.reportError(ex);}
		delete btn._destructors;
	}
}))();
