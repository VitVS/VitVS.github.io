// Скрипт Save
// https://forum.mozilla-russia.org/viewtopic.php?pid=781458#p781458
// https://forum.mozilla-russia.org/viewtopic.php?pid=799602#p799602
// https://forum.mozilla-russia.org/viewtopic.php?pid=799639#p799639
// https://forum.mozilla-russia.org/viewtopic.php?pid=805016#p805016

// Кнопка-виджет в Save_Button.js

self.label = "Save";
self.type = "menu";

// Создать меню для кнопки ...
var array = [
    { label: "Сохранить favicon сайта", func: () => saveFavicon(), image: "data:image/png;charset=utf-8;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAABmJLR0QA/wD/AP+gvaeTAAADUElEQVRYCe2WS0gVYRiGZ8pQ8oJZYXbBWkZEBFEUlQlBEi0zwWWLtoEg1ULRRSCRXQgM3VSbCIJAcNMiRGgVRVZSq1DpImam0U1Nz/S80//JOJ6bYUTg4X2+9/u//zL/XM6Z43lLn398BfyFHD8IgjzGV0IVyDfh0hvCA7gP3b7vT+KLJw5cAq3wBTJJYy4waNWi7ICFauETmH66ZAK/61BOGlif8lFCzR9vgsk+NEMCpP4gCK6C9IOwxxYn3we2iSvkgyBpbiOJb2OzdiY1gamNJBdegnQhvhDFVpD6CHnQAaaG+Pi0bWbVQAKk0xpMshekKUKpalGorQO7BbvVR7sOJK11XLWMMLoExkBqtQk0LoLUabW409kFUov10dAtwQI9R6usbp5jScTPkRfDMDxmZjUuVSnAeKRGc47GXOsoY564/BE+AmvhLJyBWc15OJikDY3SWwR/Q+MsuobfiRk8lA4YJi5U4jr4NP4cApBWEraCJvbi6bSTzmXwCr6D5BN2QDEchG6YL65AC0i3o70UjoD0OlpPljNoAKTD0X4Kd0A6H61rp9F2uWv0OTfTVVE+ppAB3UIN0dnKjRcusWOEzfgGysKq5w05N8t3yTfn6eyr6yxwbmZrbrCCPL4B3SvVA4UIqeqRIbNpqrHxNcMJ8Q28Dauet965Waqzsv6oF7qGzXFNb6NL3jkPLb4BvVbVsU0hwmeXr3aezmzMeGyQrTkYrfvRBo+oviI91BIwCHbZcsl171Qf8NJ/ttDtg850EpfULifRCR/gd+AheSh1hIkCG8jBR8GeetJFla5K6h8idjbNJto5ZD0MwUmYBukSYTtch3uQTNUUT0Ev1IO0gnADSqGdY8zgqcUGCmAIpJue+9C4CFKnK80zOpO9jG5Rl94T8udNSlZgYLLX8R7qUqrXcRmd9jrepXVp14GU/etYEwWzmsDURpILz0C6rDFRKF4D6SkhDzrA1BAdm1XOTB+aQbvHgv4gCC6BNEXYbwuRVwTB7P9B/TMapC0lCI0w52G3eVk5k2vhI5jsMk9QSPendIT+E1kdJNMgFioC3ZIPeCYNM0BnXZhpXfUv6NKw8HImHfI87xhUwGbv96cf64Eu6PF9fwZf0v9xBX4BW7VJooPQ4WAAAAAASUVORK5CYII="},
    { label: "Копировать favicon сайта в base64", func: () => copyFaviconData(), image: "data:image/png;charset=utf-8;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAABmJLR0QA/wD/AP+gvaeTAAAC6UlEQVRYCe2VS2hTQRSGJzFFMFRtEUNBaRptpVUEFdyoCxcuRESkBVcGEYRCEQUXQXBpoQjik25EkSxEfCDiSkEUbNGCC1204KOoIBqQplRplRpz/f5wpwwxbZ6ii5b/m/OYM2cmNzdTY+b//vETCFS7v+d5IXrsgD3QBmFIwQDcCAQCH7B/R2zeBW9gNmWYSEKk5ieg6UnI1wiJXsjXexIdNTsEzQ6D1YDvZLEbtQn2Jkh6Oik58M7zvGWarwqaROEHSKcZekB6ahsTbAcpzRADe4grtsbaoHXKsMepXQhTkIaDIP1io4Qg2AIeNEAPDIEUZz4mpyJYHIIxqEYJd/OQG5TgR40xjZCBOyB1MgThAUyA1WacZhiBYVgNG2ATVCY+9laQPtoOBHr0GK/V5mRJXAap14/3K4Anii0h65RoJ/26MI3sJ8mS0xNYT24xvtVy34mQV60uKaW+a6gIGjVABqpRv7u5Tu7Gc/pcq+MUPAPpJ4NiWVyjT6bY4ikJ3+ArWOldsX75lo++Cs6Dftsd2LMgJW03gpWQ9WnCXgXpLUPxr50iNbiIHYdpmIALUO9ssoS4CzpBSjOENY89BtJLhjMg6UA7NV8QKvSyJLDDMJt0AyaZXGub4AdhN9wH/R9own4GKaPB54RdU9BS9BpKlRrfonib24x4DdwGV1MEh9y6gj5Fo1CJXrHoCCyyjfFPwRhcghabn9NSWOkBWJqTvh79nzBE+loWuBuSa4HrcBfWuXM5n2S1B6BFTjPNieogDs/B1WBuU4biPwmKylDuLmCnqDGmGw4YYyKQr082EbAOi0bxY1Cp0ix8bIwJwi6og3xNk3gI+7jUdEHh+tIBwNUggS6ZIWy1ytLgGjT72/1pmNQ7oJ/MOfw2t4K4FfrgC5Sreyxod/sV9Ck6CisKTvpJ5uuhG15AMele2esvrb1h93boA13BmBnpKcWJ9C7UfuP8jmzUCP2Qgkee5y3Nr5mP/+sn8Bs4IBR11QNlKgAAAABJRU5ErkJggg=="},
    { separator: ''},
    { label: "Сохранить ярлык страницы как …", func: () => saveShortcuts(), image: "data:image/png;charset=utf-8;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAABmJLR0QA/wD/AP+gvaeTAAACsklEQVRYCe2Xy29MYRjGe6Z0U6UXl2RiTCoV0UU3EguxlBaR7qjoiKWyROzUyr9g0YuNS9jwD4iSSCxQS0NqEjuShhKNykzm83uGd/rN6BzmnDMrTp7f977f7XnPbU4ybW3/+hG04gY45zbiOwy9UILHQRC8JbZWFA7gEnwBX2U692Bry84A83a4CWEqMLk58ZPAVMVvE03vSc7AIByGR2C6k+gJ4FpfPM9Y2i9CX49mzv08yoSMPx8rx+w6mH4rbuYsOASmkzYeK+J22q0eDYurCMuGwDShsVjgpNv6higt0mwPM2T+HJiOhK39qzmcdoPpsjbR6YQO5T6MZZ1zOkmCW6Lp9Ocj5ZgcAOk5TTecgBV4BevMlDzrnCuA6bzNxYq4DcA89MIYFEFapumSOTHraotP0U/m6ysj6INjYMW/k4/+Kt5P7l/5DP2U5ppGG2EI9kLGDMhPQQmkbzTDoMcxSVwC0wxJ5OI5Ni+A6QWJbnuOWAJJxUdINK53grSqa2TNF9cm0GZCVc/IeiAHJZBUXB+ZPjrzYFogydndaiqyMQWzYPpEotvaTRyHEkiV4jKnE8AuOAh7NBYJNtcXLzDWLzPiKOhFI7gijV5AXXmg+dhgqKuYJppUPCtjBrpgGaQizXHQM39J3Kk1scHoApiqxWXM4HrIwwqMgd4Fe+H2a00sMNwAn0FapKlcuW/KWAdUPqPEK271GPDXRcrxOgqms2EmLMrAR5DyYWv/NJfyFuzw8ideXpNSMc3AA+gB6aqa2GA8DqaRtQyZTMNrMM2utS7SGI5Z51wZpIc0NT8t+vXFbzHWHqlYo00Y3gXTnHNOX7hB4gR8AFPyxXVSuG+BAoTpBpPJXrmKG5hvg/tQL/1ELzJY82hsX9TY0IxC+g7sw3gTvIOn/L36SvyvRO/AD94bS0nNXI/tAAAAAElFTkSuQmCC"},
    { separator: ''},
    { label: "Сохранить страницу как PDF", func: () => savePageToPDF(), image: "data:image/png;charset=utf-8;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAABmJLR0QA/wD/AP+gvaeTAAACt0lEQVRYCb2XS2sTURTHz8T0aQ21tVHRLtxYqI+F4EY3UVCLi8YHSKG40KWK+Akq6kcQv4Da+liIpbrwRWtF0ZUENyq468JSC8VqtaYl/g5k0pvJTHJ7Mxr+v3vOvXPuOSczk0kiEvIqFAptcA0+w0+w0XeCHsK2kJT2SyTogBy46hsb99pW9IKBbL7N2iCoXjE8gjmopg4ODkELqOYZsp7njWPtRfFNsASqOwwVDUZlI1bjMSX9wuuLivfXE75TtLuwa0B1g3dQUMeS6UBcM/MHNHEEG6lgA61G5Izh27iLIUEtrI3SxGFsqIINhAbVudjEfm0iIyGv/9GAlvUvx26dmMTZwLKZOMRfz5reqA3YkpIlr37nHikyItIIpjYy2QqqXgZ9RrzBVoqbJQu+eioj3FZIeB58Zc0sTpeATPq0fImdhA1mwgj/ecS6ODVAsuPQDZ3gPzVxVy/XBhYo1QrTkAJnuTYwTsU07IMv4CynBnhEf6XiGDTBa3CWUwPFai+K1uYmLIZWmnoa6CfdPNzkk9CMdZJTAxTcTLWMiJyCdTDCmtNDzWkTBS/AR3gCR+EdjNHEb2wvqCZE5CL3yyI2Uqs+AxRJke0c5OAWTMIS7IBjkIApOAOHoKo0uGqAeZDi+tPrOmvt0A9/4DSkYTtchjzshAkR0TODsRQFQr8LWE/CJZgF1RBDyjKtENsDvsq+C5K1krCrkZjHsAf0nT/jul7Fj0U1G6DKQTgAH0BP+VlsbLJp4C3VRsGDE7z7KWxsStbKRME5Yk7CP1EikHXBmHcZfr1u2kjww/DLXW64LnD6Y1KeaWVGPg/ugyrP0LlyVKTsEnC6Zwi4S8AgDMAW5k+xeXBRA5v6YD+ohqkxq04kFNSfWzls3HpPwvbIwuYBAtvA/3u+jO8q3fuJzVdgrVnD9/8CvFxMGTTWer0AAAAASUVORK5CYII="},
    { label: "Печать страницы / печать в PDF", func: () => document.querySelector("#mainCommandSet > command#cmd_print").doCommand(), image: "data:image/png;charset=utf-8;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAABmJLR0QA/wD/AP+gvaeTAAAC6ElEQVRYCd2WzW8NURjGZ6hqKFckNIidhUY/fCysmm7KxkaIhAVNETtJcxf+AURISxMbEZvGBgtBokU3NrpxW410JxVarCiVNKQtx+/Re2TmzseZe29Xmud3zpz3fd53zkzn3ju+52X/M8Ycwn0V3kMBRkDzG9/3Dcdlyy+ngg2M498BpfpOYBS0GbupiSybyrwBTr6LE+gkTN4kwyZYAUn6RkKbsRTY0FtiIZWzgV4q87AAW0AnaGbeA7tBs9YrOU7SVxLBu/Qk0wa4+uUUToGueoArOcBxRPh0R5pI2A1pbmVdB3EqxAUjMRrvA6ujEUNKgKIaaIEuuA7DMA+SnqmU6mIKZz9IMwyriuGKJuo3wAJIF5xNcNXDLEi3nAUOA03OgJUe7PQKnMfBqj3d7c7SaBCkCbcbB84BkKYYlhGqWNTn4CdIfc5GuBrAPjCXnQUOA72Cd7PNYfc8CvJg1egscBho9BikdwzurwBMIyBl+7ymbIAm62EOpN4U62IKVxNYdS9GKx9pdBKs9jo74TwPkj6zm50FDgONBkGaZMh0+x9ilJ46ejvTNGkA+zBfCRWQaIW1oSALYo1wCbaxrEr06AarllAzondBn817zB3gvj2hDu4FPV+BNBpxEx2GoF6yOA2rI+YKAvRpBqt8pAWZIYjTD4J/70qkqIwAPS6C9ItB7xHhaoI3wKUXGE5A0u96uGlxhb8WPoE0VAyHJzJtkFVfMF6D7eEu8St8x8DqSLyLKA49iEyZ9RvnKUoTRd6HMZA+MuhtKeK3v25dZB5AVvkYN0KaDpPU6xiT18Nr3LwOUmGX++EZZFF/UjOK14Gumsnom68uyRsbp2on3IY5SNI0ifrSBorBc7A6WOrJvKbDVuiBGYjTfYI5NWTW/7yDeRysbipXNXTLwTn4AKWaJTBdhOmf7nBUU/XJgw1oWAudxpjXkKTPJM6CH6xd0mM1h3ZjTB+MgU76iLnTGLNmSU/23zf7A6yAD944M8WnAAAAAElFTkSuQmCC"},
    { label: "Сохранить страницу / выбор как HTML", func: () => savePageToHTML(), image: "data:image/png;charset=utf-8;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAABmJLR0QA/wD/AP+gvaeTAAADCUlEQVRYCb2XTUhUURTH37zU8mORNtpEJTQIQlCrgqiFrkoImk2EYS2jhW3ah5TRqpULoVZtkrJFZbmoGBDsaxXZrhEiamdWZJZW6ky/I+8OZ968N+/Om0j+v3vOvfe8c8+7780dx3EC/gqFQgtchln4CTb6TtB92BWQ0n6IBG3wBuLqMxfut10x4Q/k4puMDYDoKc0kfINKamNyCBpBtEiTSSQSU1h7sXgKVkF0i6aswLBsxEo8pqhlvL6weDPuGseze7AbQDTKHRTEsWTOF7eJ/l2KOIINlb+AJhU5r3wb93dAUCNjExRxGBsofwGBQTUObuR6KaLXCfj7HwXIsuZx7JWO5l8WsKYTB/itjMmLWo8tqq7o1e6Mk6LXcZwG0NpKZweIdtPIGfECWy5elgwYdZdHxBsh4SAYZXSWWI+ATC5MwjikdcIQPxsy7rhhE5XGOR/yzD+EE/CMIpLYWIpVgLfSrGe3YQchlmopIKVWbGUX5LFUvRO1FNCvCsjhyxH+ikLS+NZyrSMJJPkQpEG+LY8xZHQQ5wp0wghYq9pz4CuZn0MHiOZo5HN+CmtUzRdY1Z+CHlZJgdm5e/hToPVId6J8kygqzmHbzxJ0HIwWcWS7P2K1lnUnynejAtT8sPLz+KfhAxyFP2B0kWK3mE6UdaMCZJ6E8q4kxfe4xmE0gb8PkpCF9yDqpLkKVrIqgMVWyfYOjKY9R17Ic/gXYAGMBii6wXQqWbfSpG/uuurvFJ/C8jCKPwODYCRnglVuqyAv6wg2C6Iz3KH8kyG+QxEFnC4wesDYL9OxtiSt+HXMfBOMgegxTRc0w0mYB9EMjTkn1tem3w1GmfVBr6lmB+ROl7gzOQV7uH4BXsIPuAFv4TwcIOYT1kp1vqgl1W/Hz0GZWGCaQQFjpQ4VJQWrrnLZo3aI9cNEpSlxyZeAOyBaoSk5I0p2gDuT53ibDLLN/djtXPAEuwJxVM9FfXAIRGOs8UWcUFiw1h+npAjUa0Y3hy6sJwhsAfPzfA0/ruTaHBdfgma9hvH/Ag7EeepKNPfrAAAAAElFTkSuQmCC"},
    { label: "Сохранить URL, страницу / выбор как TXT", func: () => saveSelectionToTxt(), image: "data:image/png;charset=utf-8;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAABmJLR0QA/wD/AP+gvaeTAAACKElEQVRYCe2XP0scQRjGd2WjpRAQi4ipvOvSCpIujX8gEkIasVA5CxG0igGLhFj4MfQ7CPkGp5Upki5nYQKiiCAnCpp4cP6eeIOb2ZlZMeddocfzm3nned+dnZudO70osl71ej2GWfgKF/C/0hzbTFKybuUeUvgZ7kuf7LvGaYO7PmP8M4qiBD7CITRDvUyyAjXoj+P4gD4rFjACRsVsxd0cJiyC0XB6lo70gLgT7ltd6RvYC0jnWhK3fQE6bMF3yoN7ScE0SIscoDM8Pcd3MnJYp74cqklCyUauQD8D0geaM3gBxiP0apNMGbxKvJmbxAlhBaSaGjgG4xF6pWu9yUyCrR0Ho2Km4I4GE6Y/huPpaTrSg3bEuY+A1b9iYQsgTXKoTvHeMJiKwq85avfDJddfuXk1zyl4DVIXzSkMgPEInVpyupaZuwPU6+/BFr10qQb2wHiETp073ZDJ1j4ewswGsStjmMsgjXKwTvAmGMxDnlap/xIqSkLJRq6XfgikJ2qgD4xH6JWu9SaVuM0CflG4AdJvNbADxiP0Std6k5kEW/t4CF278hZzFaRBDlWVnSoxeA8hDVO7GypQLlGTQzf5Akim/ikD4xE61el0LdNMaNn/DCuM1kC6UAPfwXiETlWdbshkax/eIWz7/wP2Av6EHlGTcubL7O909iHU4aqRka8fqEfEzVBPYxLN/a0RuzsOYkt/nGZWwQJi0Lv/Qd8saa5S5mYYV1bQVfz1oDyqAAAAAElFTkSuQmCC"},
    { separator: ''},
    { label: "Копировать изображение / текст в base64", func: () => copyFileToBase(), image: "data:image/png;charset=utf-8;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAAEEfUpiAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAM/SURBVEhL7ZdfZNZRGMfPuzFGIyJGdBExRaTxXqQRXY0ouxgjIiKi7hsxIrqLXUVEKV1EjGU0pYgxIpaIXYwRJbqIkbfP95zn+fn9eX/vu3d7I+nL933Ov+d5zu+c5zznvOGPoNVqvbNiRKPUMGUygc5JKybVsrowoJ9cxyv9UB+DTZUb1qABD+FMo9FoUl+m/B0Ow3ow8LAVu4CRs+amggE6DiA35Ts1lSBNpzX5pBNKHXfgCJyBcZG0lPuQz+GgfaIUNqBcv4ftYQPTStbgnsndIW6FgMsniIPwM9RWjDPny8juQPmtz7kTNKY8zr9xEG7ReRKOwgc2+HjqTk4kyxvmBrbgEJ1v4Cbli7E1hFP6QXkBEbfB6jKe9kk/Ag3al0dwKDaEcAaFHypIIbZUIWe9Iz+DfwD5RdT5fQF9ERdZxJtWroVnDZ0YRZ+Unxr3w+3BVrVrJLaDUsJeK9832RaMmzBHhUykA38aeStVC8gCSZCypEejQ2twIhVj1lDyvRprISyZlPKoFedMZpCBj6kY5rG+AVcor6WmDApxeV/A2KQYW4EMaPWFKyYF9yjvOqna4sexIYRZY4Tn9tcIbaGS/wjUMf6Ax0v0KXUdhatQht24cvG5GAcUdGw1YAJKeUHKSEExIqg9mxnIl7cPZlSImTiD3WAnBrQm/UnpfwWydNAOLLaHhO/YF/iJHdbd2BdUJoBThY3O5rHY0B6rTCIf+P0Bzm97mEFdluetqwDaOz9+ekA+I+t4+hnXdTXFV/5K1d6BPUWqH8IlbM1buQBPBWOIfD7VVaAcom04Ar/BdbiMIZ34jsCenPmrYAUdz5AV+AQuIHrZU6WaSmoVsKX4UY4XFLCyXQtPBHtMCj9RapZJ+1n1xRFsFY4qLy/ariHc+VfoT5xa+ATiw8kwjKHKCWAS8QimWoS2LQM6M4jpVAu6yabRiTFEnwe2WHjReDbXW9fvC+EuA8etHEFdX5yfmB5sEWbU91lO9Zchu047oZAHMKTr5AZUAqqDVuI6DvQQjkDvGaLX6yXeZ5VE5MCoLshDUIaV+dZR0DO2Z2Ar/+SZw062erW3kZzBNfgSKpp35LwbdnId/kcfEcJvJ7yZGHuzI6wAAAAASUVORK5CYII="},
    { separator: ''},
    { label: "(Меню ПКМ) Сохр./добавить текст в файл", value: "Save.SelectionToFile" },
    { label: "(Меню ПКМ) Открыть текст в редакторе", value: "Save.TextToEditor"},
];

var menuPopup = self.appendChild(document.createXULElement("menupopup"));
array.forEach((m,i)=> {
    if ("separator" in m) { menuPopup.appendChild(document.createXULElement("menuseparator")); return };
    var mItem = menuPopup.appendChild(document.createXULElement("menuitem"));
    mItem.setAttribute("label", m.label);
    mItem.setAttribute("class", "menuitem-iconic");
    if ("image" in m) mItem.setAttribute("image", m.image || array[i-1].image);
    if ("value" in m) {
        mItem.setAttribute('type', 'checkbox');
        mItem.setAttribute('checked', cbu.getPrefs(m.value) );
        mItem.onclick =()=> cbu.setPrefs(m.value, !cbu.getPrefs(m.value));
        }
    if ("func" in m) mItem.addEventListener("command", m.func);
});
menuPopup.onclick = e => e.stopPropagation();


function aDate() {
    var t=new Date();
    var y=1900+t.getYear();
    var min=t.getMinutes(); if (min<10){min="0"+min};
    var h=t.getHours();
    var m=t.getMonth();switch(m){case 0: m="января";break;case 1: m="февраля";break;case 2: m="марта";break;case 3: m="апреля";break;case 4: m="мая";break;case 5: m="июня";break;case 6: m="июля";break;case 7: m="августа";break;case 8: m="сентября";break;case 9: m="октября";break;case 10: m="ноября";break;default: m="декабря";}
    var d=t.getDate();
    var curdate=d+" "+m+" "+y+" "+"г";
    var myfilename=curdate;
    return myfilename;
}


// Копировать favicon сайта в base64
function FaviconToBase(image) {
    var canvas = document.createElementNS(xhtmlns, 'canvas');
    canvas.width = image.naturalWidth;
    canvas.height = image.naturalHeight;
    var ctx = canvas.getContext('2d');
    ctx.drawImage(image, 0, 0);
    var base64 = canvas.toDataURL();
    gClipboard.write(base64);

    var as = Cc["@mozilla.org/alerts-service;1"].getService(Ci.nsIAlertsService);
    var alertName = "FaviconToBase";

    as.showAlertNotification(
        base64,
        "Скрипт Save - FaviconToBase",
        "Значок скопирован как base64",
        false,
        "",
        null,
        alertName
    );

    setTimeout(as.closeAlert, 5e3, alertName);
};

// Сохранить страницу / выбор как HTML
function savePageToHTML() {
var vert = String.raw`javascript:(function(){var getSelWin=function(w){if(w.getSelection().toString())return w;for(var i=0,f,r;f=w.frames[i];i++){try{if(r=getSelWin(f))return r}catch(e){}}};var selWin=getSelWin(window),win=selWin||window,doc=win.document,loc=win.location;var qualifyURL=function(url,base){if(!url||/^([a-z]+:|%23)/.test(url))return url;var a=doc.createElement('a');if(base){a.href=base;a.href=a.protocol+(url.charAt(0)=='/'%3F(url.charAt(1)=='/'%3F'':'//'+a.host):'//'+a.host+a.pathname.slice(0,(url.charAt(0)!='%3F'&&a.pathname.lastIndexOf('/')+1)||a.pathname.length))+url}else{a.href=url};return a.href};var encodeImg=function(src,obj){var canvas,img,ret=src;if(/^https%3F:%5C/%5C//.test(src)){canvas=doc.createElement('canvas');if(!obj||obj.nodeName.toLowerCase()!='img'){img=doc.createElement('img');img.src=src}else{img=obj};if(img.complete)try{canvas.width=img.width;canvas.height=img.height;canvas.getContext('2d').drawImage(img,0,0);ret=canvas.toDataURL((/%5C.jpe%3Fg/i.test(src)%3F'image/jpeg':'image/png'))}catch(e){};if(img!=obj)img.src='about:blank'};return ret};var toSrc=function(obj){var strToSrc=function(str){var chr,ret='',i=0,meta={'%5Cb':'%5C%5Cb','%5Ct':'%5C%5Ct','%5Cn':'%5C%5Cn','%5Cf':'%5C%5Cf','%5Cr':'%5C%5Cr','%5Cx22':'%5C%5C%5Cx22','%5C%5C':'%5C%5C%5C%5C'};while(chr=str.charAt(i++)){ret+=meta[chr]||chr};return'%5Cx22'+ret+'%5Cx22'},arrToSrc=function(arr){var ret=[];for(var i=0;i<arr.length;i++){ret[i]=toSrc(arr[i])||'null'};return'['+ret.join(',')+']'},objToSrc=function(obj){var val,ret=[];for(var prop in obj){if(Object.prototype.hasOwnProperty.call(obj,prop)&&(val=toSrc(obj[prop])))ret.push(strToSrc(prop)+': '+val)};return'{'+ret.join(',')+'}'};switch(Object.prototype.toString.call(obj).slice(8,-1)){case'Array':return arrToSrc(obj);case'Boolean':case'Function':case'RegExp':return obj.toString();case'Date':return'new Date('+obj.getTime()+')';case'Math':return'Math';case'Number':return isFinite(obj)%3FString(obj):'null';case'Object':return objToSrc(obj);case'String':return strToSrc(obj);default:return obj%3F(obj.nodeType==1&&obj.id%3F'document.getElementById('+strToSrc(obj.id)+')':'{}'):'null'}};var ele,pEle,clone,reUrl=/(url%5C(%5Cx22%3F)(.+%3F)(%5Cx22%3F%5C))/g;if(selWin){var rng=win.getSelection().getRangeAt(0);pEle=rng.commonAncestorContainer;ele=rng.cloneContents()}else{pEle=doc.documentElement;ele=(doc.body||doc.getElementsByTagName('body')[0]).cloneNode(true)};while(pEle){if(pEle.nodeType==1){clone=pEle.cloneNode(false);clone.appendChild(ele);ele=clone};pEle=pEle.parentNode};var sel=doc.createElement('div');sel.appendChild(ele);for(var el,all=sel.getElementsByTagName('*'),i=all.length;i--;){el=all[i];if(el.style&&el.style.backgroundImage)el.style.backgroundImage=el.style.backgroundImage.replace(reUrl,function(a,b,c,d){return b+encodeImg(qualifyURL(c))+d});switch(el.nodeName.toLowerCase()){case'link':case'style':case'script':el.parentNode.removeChild(el);break;case'a':case'area':if(el.hasAttribute('href')&&el.getAttribute('href').charAt(0)!='%23')el.href=el.href;break;case'img':case'input':if(el.hasAttribute('src'))el.src=encodeImg(el.src,el);break;case'audio':case'video':case'embed':case'frame':case'iframe':if(el.hasAttribute('src'))el.src=el.src;break;case'object':if(el.hasAttribute('data'))el.data=el.data;break;case'form':if(el.hasAttribute('action'))el.action=el.action;break}};var head=ele.insertBefore(doc.createElement('head'),ele.firstChild);var meta=doc.createElement('meta');meta.httpEquiv='content-type';meta.content='text/html; charset=utf-8';head.appendChild(meta);var title=doc.getElementsByTagName('title')[0];if(title)head.appendChild(title.cloneNode(true));head.copyScript=function(){if('$'in win)return;var f=doc.createElement('iframe');f.src='about:blank';f.style.cssText ='position:fixed;left:0;top:0;visibility:hidden;width:0;height:0;';doc.documentElement.appendChild(f);var str,script=doc.createElement('script');script.type='text/javascript';for(var name in win){if(name in f.contentWindow||!/^[a-zA-Z_$][0-9a-zA-Z_$]*$/.test(name))continue;try{str=toSrc(win[name]);if(!/%5C{%5Cs*%5C[native code%5C]%5Cs*%5C}/.test(str)){script.appendChild(doc.createTextNode('var '+name+' = '+str.replace(/<%5C/(script>)/ig,'<%5C%5C/$1')+';%5Cn'))}}catch(e){}};f.parentNode.removeChild(f);if(script.childNodes.length)this.nextSibling.appendChild(script)};head.copyScript();head.copyStyle=function(s){if(!s)return;var style=doc.createElement('style');style.type='text/css';if(s.media&&s.media.mediaText)style.media=s.media.mediaText;try{for(var i=0,rule;rule=s.cssRules[i];i++){if(rule.type!=3){if((!rule.selectorText||rule.selectorText.indexOf(':')!=-1)||(!sel.querySelector||sel.querySelector(rule.selectorText))){style.appendChild(doc.createTextNode(rule.cssText.replace(reUrl,function(a,b,c,d){var url=qualifyURL(c,s.href);if(rule.type==1&&rule.style&&rule.style.backgroundImage)url=encodeImg(url);return b+url+d})+'%5Cn'))}}else{this.copyStyle(rule.styleSheet)}}}catch(e){if(s.ownerNode)style=s.ownerNode.cloneNode(false)};this.appendChild(style)};var sheets=doc.styleSheets;for(var j=0;j<sheets.length;j++)head.copyStyle(sheets[j]);head.appendChild(doc.createTextNode('%5Cn'));var doctype='',dt=doc.doctype;if(dt&&dt.name){doctype+='<!DOCTYPE '+dt.name;if(dt.publicId)doctype+=' PUBLIC %5Cx22'+dt.publicId+'%5Cx22';if(dt.systemId)doctype+=' %5Cx22'+dt.systemId+'%5Cx22';doctype+='>%5Cn'};var href = 'data:text/html;charset=utf-8,' + encodeURIComponent(doctype + sel.innerHTML + '\n<!-- This document saved from ' + (loc.protocol != 'data:' ? loc.href : 'data:uri') + ' -->');var a = document.documentElement.appendChild(document.createElement("a"));a.setAttribute("href", href);var name = selWin ? win.getSelection().toString() : (title && title.text ? title.text : loc.pathname.split('/').pop());name=name.replace(/[:\\\/<>?*|"]+/g, '_').replace(/\s+/g, ' ').slice(0, 100).replace(/^\s+|\s+$/g, '');name += (function () {var d = new Date(), z=function(n){return '_' + (n < 10 ? '0' : '') + n};return z(d.getHours()) + z(d.getMinutes()) + z(d.getSeconds());})();a.setAttribute("download", name + ".html");a.click();a.remove();})();`;
gBrowser.fixupAndLoadURIString(vert, {triggeringPrincipal: Services.scriptSecurityManager.getSystemPrincipal()});
};

// Получить имя файла
async function pick(fileName) {
    try {
        var file = Services.prefs.getComplexValue("browser.download.dir", Ci.nsIFile);
        await IOUtils.makeDirectory(file.path);
    } catch {
        file = Services.dirsvc.get("Desk", Ci.nsIFile);
    }
    var fp = makeFilePicker();
    fp.init(window.browsingContext, "", fp.modeSave);
    fp.displayDirectory = file;
    fp.defaultString = fileName;
    return await new Promise(fp.open) != fp.returnCancel && fp.file;
}

// Сохранить favicon сайта
function saveFavicon() {
    var dn = "favicon";
    var re = /^data:(image\/[^;,]+)/i;
    var ms = Cc["@mozilla.org/mime;1"].getService(Ci.nsIMIMEService);
    (saveFavicon = async () => {
        var url = gBrowser.selectedTab.image;
        if (!url) return;
        if (re.test(url)) {
            try {var name = gBrowser.currentURI.host || dn;} catch {name = dn;}
            name += "." + ms.getPrimaryExtension(RegExp.$1, "ico");
        } else
            var name = Services.io.newURI(url).QueryInterface(Ci.nsIURL).fileName;

        var file = await pick(name);
        file && IOUtils.write(file.path, new Uint8Array(await (await fetch(url)).arrayBuffer()));
    })();
}

// Сохранить ярлык страницы как …
function saveShortcuts() {
    var img = self.getAttribute("image");
    var as = Cc["@mozilla.org/alerts-service;1"].getService(Ci.nsIAlertsService);
    (saveShortcuts = async () => {
        var file = await pick(getTabLabel() + ".url");
        if (file)
            await IOUtils.writeUTF8(file.path, `[InternetShortcut]\r\nURL=${gBrowser.currentURI.spec}\r\n`),
            as.showAlertNotification(
                gBrowser.selectedTab.image || img, file.leafName, "Сохранил в: " + file.parent.path
            );
    })();
}

// Копировать изображение или текстовой файл в base64 ...
function copyFileToBase(){
var fp = window.makeFilePicker();
fp.init(window.browsingContext, "Открыть файл", fp.modeOpen);
fp.appendFilter(
"Text and images", "*.txt; *.text; *.css; *.js; *.ini; *.rdf; *.xml; *.html; *.htm; *.shtml;\
                    *.xhtml; *.json; *.jpe; *.jpg; *.jpeg; *.gif; *.png; *.bmp; *.ico; *.svg;\
                    *.svgz; *.tif; *.tiff; *.drw; *.pct; *.psp; *.xcf; *.psd; *.raw; *.webp");
    fp.open(re=> {
    if ( re != fp.returnOK ) return;
    var file = fp.file;
    var inputStream = Cc["@mozilla.org/network/file-input-stream;1"].createInstance(Ci.nsIFileInputStream);
    inputStream.init(file, 0x01, 0o600, 0);
    var stream = Cc["@mozilla.org/binaryinputstream;1"].createInstance(Ci.nsIBinaryInputStream);
    stream.setInputStream(inputStream);
    var encoded = btoa(stream.readBytes(stream.available()));
    var contentType = Cc["@mozilla.org/mime;1"].getService(Ci.nsIMIMEService).getTypeFromFile(file);
    var dataURI = "data:" + contentType + ";charset=utf-8;base64," + encoded;
    gClipboard.write(dataURI);

    var as = Cc["@mozilla.org/alerts-service;1"].getService(Ci.nsIAlertsService);
    var alertName = "FileToBase";

    as.showAlertNotification(
        dataURI,
        "Скрипт Save - FileToBase",
        "Файл скопирован как base64",
        false,
        "",
        null,
        alertName
    );

    setTimeout(as.closeAlert, 5e3, alertName);
    });
};

// Сохранить страницу как PDF, скриптом ...
function savePageToPDF() {
    var ps = Ci.nsIPrintSettings, cfg = {

        paperWidth: 8.5,
        paperHeight: 11,
        paperSizeUnit: ps.kPaperSizeInches, // kPaperSizeMillimeters

        marginLeft: .2,
        marginRight: .2,
        marginTop: .2,
        marginBottom: .2,

        edgeLeft: .1,
        edgeRight: .1,
        edgeTop: 0,
        edgeBottom: 0,

        headerStrLeft: "&T",
        headerStrCenter: "",
        headerStrRight: "&U",

        footerStrLeft: "&PT",
        footerStrCenter: "",
        footerStrRight: "&D",

        printBGColors: true,
        printBGImages: false,

        scaling: 1,
        shrinkToFit: true, // overrides scaling
        orientation: ps.kPortraitOrientation, // kLandscapeOrientation

        printerName: "",
        printSilent: true,
        printToFile: true,
        showPrintProgress: false,
        isInitializedFromPrefs: false,
        isInitializedFromPrinter: false,
        outputFormat: ps.kOutputFormatPDF,
        outputDestination: ps.kOutputDestinationFile,
    };
    ps = Cc["@mozilla.org/gfx/printsettings-service;1"]
        .getService(Ci.nsIPrintSettingsService).createNewPrintSettings();
    for(var key in cfg) if (key in ps) ps[key] = cfg[key];
    (savePageToPDF = async () => {
        try {
            var file = Services.prefs.getComplexValue("browser.download.dir", Ci.nsIFile);
            await IOUtils.makeDirectory(file.path);
        } catch {
            file = Services.dirsvc.get("Desk", Ci.nsIFile);
        }
        file.append(`Snap ${new Date().toLocaleString("mn").replace(/:/g, "\ua789")}.pdf`);
        ps.toFileName = file.path;
        await gBrowser.selectedBrowser.browsingContext.print(ps);
        //file.launch();
    })();
};


// Копировать favicon сайта в base64 ...
function copyFaviconData() {
    var img = new Image();
    img.src = gBrowser.selectedTab.image;
    FaviconToBase(img);
};


// Сохранить URL, страницу / выбор как TXT ...
function saveSelectionToTxt() {
    // [129+] l11 = length >= 11; https://forum.mozilla-russia.org/profile.php?id=71856
    var {length} = saveURL, splice = length > 9, l11 = length >= 11;
    var msgName = _id + ":Save:GetSelection";
    var receiver = msg => {
        var args = [
            "data:text/plain," + encodeURIComponent(gBrowser.currentURI.spec + "\r\n\r\n" + msg.data),
            getTabLabel() + '   ' + aDate().replace(/:/g, ".") + ".txt",
            null, false, false, null, window.document
        ];
        splice && args.splice(5, 0, null) && l11 && args.splice(1, 0, null);
        saveURL(...args);
    }
    messageManager.addMessageListener(msgName, receiver);
    addDestructor(() => messageManager.removeMessageListener(msgName, receiver));

    var func = fm => {
        var res, fed, win = {};
        var fe = fm.getFocusedElementForWindow(content, true, win);
        var sel = (win = win.value).getSelection();
        if (sel.isCollapsed) {
            var ed = fe && fe.editor;
            if (ed && ed instanceof Ci.nsIEditor)
                sel = ed.selection, fed = fe;
        }
        if (sel.isCollapsed)
            fed && fed.blur(),
            docShell.doCommand("cmd_selectAll"),
            res = win.getSelection().toString(),
            docShell.doCommand("cmd_selectNone"),
            fed && fed.focus();

        res = res || sel.toString();
        /\S/.test(res) && sendAsyncMessage("NAME", res);
    }
    var url = "data:charset=utf-8," + encodeURIComponent(`(${func})`.replace("NAME", msgName))
        + '(Cc["@mozilla.org/focus-manager;1"].getService(Ci.nsIFocusManager));';
    (saveSelectionToTxt = () => gBrowser.selectedBrowser.messageManager.loadFrameScript(url, false))();
}


// Добавляем в контекстного меню страницы новые пункты ...
((contextMenu, el)=> {

    // в контекстное меню выделенного текста ...
    var saveItem = contextMenu.insertBefore(document.createXULElement("menuitem"), el);
    saveItem.id = "content-saveItem";
    saveItem.setAttribute("label", "Сохр./добавить текст в файл");
    saveItem.setAttribute("class", "menuitem-iconic");
    saveItem.setAttribute("image", "data:image/x-icon;base64,AAABAAEAEBAAAAEAIABoBAAAFgAAACgAAAAQAAAAIAAAAAEAIAAAAAAAQAQAAAAAAAAAAAAAAAAAAAAAAAADAgBEDRIXnwxQjKQNWp6pDFWXqAxXm6gMV5moDFeaqAxXmqgMV5qoDFebqAxVlqgNW5+pCkyIogwSFqgDAgBHDQoFhyszOv8hheP+IJH7/x+L8v8fjfb/H433/x+N9v8fjfb/H432/x+N9/8fi/L/IJH7/yGF5P0kLTTvDAcDgwgICIQ8Ojf/0czA+Oji1fzh18r85NzO/OTbz/zj287849vO/OPbzvzk3M/84dfK++ji1f3Sy8D5NDIvywYGB3kKCgqFQ0A8/+XXw/v979f/9uTO//rp0f/66NH/+ujR//rn0f/66NH/+ujR//bkzv/979f/5tfD/UZBPv8KCwqEDQwMhUVDQP/f08X7+OrZ/+zf0P/v5NP/8OPT/+/j0//v4tP/8OPT/+/j0//s39D/+OrZ/+DTxfxEQj//DAwMhA8PD4VKR0T/4dXG+/rr2v/v4tH/9OXU//Ll1P/z5dT/8+XU//Pl1P/05NT/7+DR//rr2v/i1cX7SkhE/w8PD4USEhKFT0xI/+XXxfv97tr/9ePR//no1P/459T/+OfU//jn1P/459T/+OfU//Xk0f/97tr/5dfF+09MSf8SEhGFFRQUhVNQTv/j2cv7+u/g//Hm2P/169v/9Orb//Tq2//06tv/9erb//br3P/x5tf/+e/g/+PZzPtTUU7/FBQUhRgXF4VXU1D/2828+/Lk0f/q2sf/7d3K/+3dyv/t3cr/7N3K/+rayP/r28n/69vI//Ll0v/azbv7VlNP/xgXF4UfHh6FTktJ/1JOTPtZVFL/Uk5L/1FNSv9RTUr/UU1K/1JPTP9YVVD/VVJP/09NSv9WUk//UU1L+05LSf8fHh2FIR8fhVVTUP9FQkD7UlBM/6Wlj/+4uJ7/sLCX/7S0mv+xsJn/oKCQ/6+vmv+hoYv/TEtH/0NCQPtVUk//IR8fhSMhIIVcWVb/SEVF+19dVv/f3sP////e//X10v///93/2di8/1lYWP+eno//5+fG/19dV/9JRkb7W1hV/yMhIYUkJCOFXltZ/0tJSPtdW1f/0NC4/+/u1P/h4cj/8PDV/7++q/8vLC7/e3lw/9fWv/9eXVf/TElJ+15bWf8lJCKEJSQjhF9cWf9LSUf5XVtX/tbVwf/5+OL/6enV//j54v/GxrX/QD0+/42Kgv/d3cr/YF5a/k5LSvlhXlv/JSUjhCkoKIZpZWT/VVJR/WNhXP/V1cT//f3s/+3t3v/8/Or/zc2//01LSf+VlIz/4eDS/2hmYv9YVVT8aWVj/ycmJoIaGRlYSEVE1DYzM8NKSUfP0dHG9/X16P/n59v+7e3g/+jo3f/X2M3+6uve/9bWzPdOTUvNOjg3y0RBQLwPDw8lAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA==");
    saveItem.onclick =()=> saveSelectionToFile();

    var editorItem = contextMenu.insertBefore(document.createXULElement("menuitem"), el);
    editorItem.id = "content-editorItem";
    editorItem.setAttribute("label", "Открыть текст в редакторе");
    editorItem.setAttribute("class", "menuitem-iconic");
    editorItem.setAttribute("image", "data:image/x-icon;base64,AAABAAEAEBAAAAEAIABoBAAAFgAAACgAAAAQAAAAIAAAAAEAIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABcXFz/Wlpa/1paWv9aWlr/Wlpa/1paWv9aWlr/Wlpa/1paWv9aWlr/Wlpa/1paWv9cXFz/AAAAAAAAAAAAAAAAXFxc//n7+f39/v3+/f79/v7+/v7+/v7+/v7+/f7+/v3+/v78/v7+/P////v////2XV1d/wAAAAAAAAAAAAAAAF9fX//7/fv/FVcX/wBIAv8ASAL/AEgC/wBIAv8ASAL/AEgC/wBIAv8VVxf//f78/2BgYP8AAAAAAAAAAAAAAABhYWH/+/78/zRtNf8otUX/KLVF/yi1Rf8otUX/ZLal/ypBSf9Upcv/NG01//z+/P9kZGT/AAAAAAAAAAAAAAAAZGRk//v+/P9Yh1n/MtB1/zLQdf8y0HX/MtB1/3PZrv9Tpcz/AXfF/2WYiP/8/v3/Z2dn/wAAAAAAAAAAAAAAAGZmZv/8/v3/gKSB/zvdof873aH/O92h/zvdof873aH/Fsj4/wSo6/8Ldr3//f7+/2tra/8AAAAAAAAAAAAAAABpaWn//P/+/6fAqP9C4bn/QuG5/0Lhuf9C4bn/QuG5/1vkxf8GwP7/AXfH/5HD4v9ubm7/AAAAAAAAAAAAAAAAa2tr//z//v/L2sz/lt7S/5be0v+W3tL/lt7S/5be0v+W3tL/Ms34/wSv8P8Abr7/cnJy/wAAAAAAAAAAAAAAAG5ubv/9/v7/6vDq/2Xo3f9l6N3/Zejd/2Xo3f9l6N3/Zejd/2Xo3f8GwP7/AXvJ/1uPsP8AAAAAAAAAAAAAAABwcHD//v////Hu5//l4NT/5eDU/+Xg1P/l4NT/5eDU/+Xg1P/l4NT/XNT5/wS39/8Abr//5PH2GgAAAAAAAAAAc3Nz/////////////v79//7+/f/+/v3//v79//7+/f/+/v3//v79//////8Gwf7/AYPN/xh+wukAAAAAAAAAAHV1df//////7Onh/+Xg1P/l4NT/5eDU/+Xg1P/l4NT/gYGB/4CAgP+AgID/U67L/wS2+P8AbcD/4ezzIAAAAAB4eHj///////39/P///////////////////////Pv6/4CAgP/9/f3//f39/4GBgf4Nwv3+UI+q/4x+d9IAAAAAenp6//////+Wlpf/9/X0/5OTlP/18/L/k5OU//Lv7f+AgID//f39/4GBgf6EhIRd8OXhU8yplP9yWU7/zsjCXH19ff+3t7f/////KLq6uv////8ourq6/////yi6urr/gICA/4GBgf6EhIRdAAAAAAAAAACxqMC5HhmE/wAAdP+AgID/gICA/56entOBgYH/n5+f1oGBgf+fn5/WgYGB/4GBgf+EhIRJAAAAAAAAAAAAAAAA5Of3EAcKj/8AAHP/AAesQQAHrEEAB6xBAAesQQAHrEEAB6xBAAesQQAHrEEAB6xBAAOsQQADrEEAAaxBAAGsQQAArEEAGKxBADisQQ==");
    editorItem.onclick =()=> textToEditor();


// устанавливаем где и при каких настройках показывать новые пункты ....
    addEventListener('popupshowing', e=> {
        if (e.target != e.currentTarget) return;
        var sel = gContextMenu.isTextSelected;
        saveItem.hidden = !sel || !cbu.getPrefs("Save.SelectionToFile");
        editorItem.hidden = !sel || !cbu.getPrefs("Save.TextToEditor");
        }, false, contextMenu);

    // удалять новые пункти при изменениях ....
    addDestructor(()=> {
        saveItem.remove(); editorItem.remove();
    });
})(document.getElementById("contentAreaContextMenu"), document.getElementById("context-sep-open"));


// Сохранить или добавить выделенный текст в файл в папке загрузок, если назначена,
// иначе на Рабочий стол .............
function saveSelectionToFile() {
    var line = ".".repeat(62) + "\n";
    var hint = "Нажмите чтобы открыть файл";
    var prfx = "Выбранный текст сохранен в файл ";

    var img = self.getAttribute("image");
    var desk = Services.dirsvc.get("Desk", Ci.nsIFile);
    var as = Cc["@mozilla.org/alerts-service;1"].getService(Ci.nsIAlertsService);

    (saveSelectionToFile = async () => {
        var time = aDate(), url = gBrowser.currentURI.displaySpec;
        var text = `${line}${getTabLabel()} - ${time}\n${url}\n\n${
            gContextMenu.contentData.selectionInfo.fullText
        }\n\n\n`;
        try {
            var file = Services.prefs.getComplexValue("browser.download.dir", Ci.nsIFile);
            var msg = prfx + "в папку " + file.leafName;
            await IOUtils.makeDirectory(file.path);
        } catch(ex) {
            file && Cu.reportError(ex);
            file = desk.clone();
            var msg = prfx + "на рабочий стол";
        }
        file.append(`Save - ${time}.txt`);
        await IOUtils.writeUTF8(file.path, text, {mode: file.exists() ? "append" : "create"});

        var name = "sstf-" + Cu.now();
        as.showAlertNotification(
            gBrowser.selectedTab.image || img, msg, hint, true, "",
            (s, t) => t == "alertclickcallback" && file.launch(), name
        );
        setTimeout(as.closeAlert, 8e3, name);
    })();
};


// Создать текстовой файл с выбранным текстом в папке загрузок, если назначена,
// иначе на Рабочий стол, и открыть в редакторе ...
function textToEditor() {
let browserMM = gBrowser.selectedBrowser.messageManager;
browserMM.addMessageListener('getSelect', function listener(message) {
    // создать текст для записи
    var text = convertFromUnicode("UTF-8", message.data);
    try {var file = Services.prefs.getComplexValue("browser.download.dir", Ci.nsIFile);} catch {file = Services.dirsvc.get("Desk", Ci.nsIFile);}
    file.append("TextToEditor.txt");
    custombuttonsUtils.writeFile(file.path, text);
    file.launch();

    browserMM.removeMessageListener('getSelect', listener, true);
});
    browserMM.loadFrameScript('data:,sendAsyncMessage("getSelect", content.document.getSelection().toString())', false);
};


// Конвертировать текст в юникод ...
function convertFromUnicode(charset, str) {
     var converter = Cc['@mozilla.org/intl/scriptableunicodeconverter'].createInstance(Components.interfaces.nsIScriptableUnicodeConverter);
     converter.charset = charset;
     str = converter.ConvertFromUnicode(str);
     return str + converter.Finish();
};


// Получить название вкладки без не сохраняемых символов и лишних пробелов ...
function getTabLabel() {
    var label = gBrowser.selectedTab.label;
    var label = label.replace(/[:+.\\\/<>?*|"]+/g, " ").replace(/\s\s+/g, " ");
    return label.substring(0, 50);
};
((main, parts) => this.onmousedown = e => {
    if (e.button) return;
    this.onmousedown = null;

    var df = MozXULElement.parseXULToFragment(`
        <menugroup orient="vertical">
            <menuseparator/>
            <menuitem class="menuitem-iconic"
                image="data:image/png;charset=utf-8;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAABmJLR0QA/wD/AP+gvaeTAAACpElEQVRYCe2XT4hNURzHz8UwwxRGwxTKZPGksCGLWXg2ZmbjlVJqZKMUlpZKycZaycpGZFiIUiQZJcpCYsdi1jSjZIZJM6/n8y3nde6f887p3sbbeH0/5/zO7/zO7/7euefe3jOm4NNqtfrhCnyGnxCjHwQ9hOGClPEuEgzAByirWRYeiL1ikg1k8W18EyC9onkM36GTBpi8BH0gzdE0kiSZoo8XFx+CJZDu0uQK9GUjVvF0bS1gjfnirX+FNf72e+hXgnSdb9CSEcnXTFwv4wcUMUrvVbaAtU7kjGPHmL8LgvrwPaKII/SFWlXodZwsHmI4CdshJ3ZpZ86ZdqxhqCLGiX1pMp9gAcSr+kP0VdTLYt2OOkV8xG4rewvaE7EGO2RzNANrNjKvg9pD31bMDjwj+gWshyLtMMZMwz2oG2NWg6stDLaBtJtG74g39HnxbRpgVctHlPOQ8DxYNdwsdvtc33LYz31J/1UBvuub4Blg3/ayehyka5xiveEOMqib8OcJ8alTn10SLIAF++EqSDdpFkCPpfUx9Eovs44FdP0WpEpnu5frKaiR26orT0Hqi7qD4Bmg7BEWnALpAodqHt8og2MQ0i3iX3cKChbA4hqcAekizTzsA+vD9OotM5UL0K+baRJJTTWgX0jWx9ArrfVO5ibY2v+HsGhXDuM8C9JpDtUcO3WUwUkI6QbxU52CYg7hMAmOg3SORvd1F731YXr1lJnKBcyS5B1IS2rgC1gfplda653MTbC1XT+Ev5yqBh27qrnZSaD3iDN0THZgEEr9MXHSpEzyJXAfpEWaTW5A6hByYmcImCRgAk7AVsb6TbiIXUY9LBqDEZDucI1vMrxwwap/TklRqPd4N3gv7E4Q2A/273kTu6y09hOLL8M69xrW/gOmqWkAQxEbGgAAAABJRU5ErkJggg=="
                label="Сохранить всю страницу как PNG"
                value="all"/>

            <menuitem class="menuitem-iconic"
                image="data:image/png;charset=utf-8;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAABmJLR0QA/wD/AP+gvaeTAAAC1klEQVRYCb2XO2gUQRjHd+OeMZpCTxIFAz5ATwVtfKDEIpUGES6oiBDUQiWFvU1QEBEbO7HSRohERYIBKxEU9bQSuULC2YiFYIjiKzHKGdffd2SO2b3Z3dnNmfD/zXwz871u5y7HOY7hz/f9drgIb2EKbPQdp/uw1pDSfosEeShDVn0icIdtRTfsSPAQe/0gesbwAL5CnPIcnoc2EP1gKLqu+5jZXhRfCX9ANMzQ0GBUNnzFn6muaazeKH+136KM2XkL8wIQXeMV+GJYMh7yW8R6hCb2MUcq3MBizXNCs23M3wanNvZGaWIvs1HhBoxOc9xsJV6a6HEMf/PRgJRV17FVFjrNbGBGT2ywl7Enb9Qcc11e3YoxuEMJWhfj8p6zO9DjOM5C0LWCRReINjPI/4gXzI2iUBGUCsqDjQLEqVv5mmYCz4BSUfdp0Rf/0X4UldvqCgj+AH0QpbGog6R9qwb4hzRJolFouqwa4PLkY7QtZfVXNP4rKcaqAZKshueQRhtxrkCs5utNGNmEF3kSPJDP+Z7gVuJKYhKdrBqYvctSYrYMDqmugDdjDk7DFdiUoV5DiNUT0KKGsA/DNzhGE2t4OtPYmWX9BCi2nSpH4CycgE7YAHOSdQNU2QWiGwxdIPpIY61wGWrfB8wH4CYMikMSXpKDdp7D9kF0kqHM4x+n0HXsU3AI+yXzcXgHJUgnEhi/DSULZztBVJIB+mAA/sITEFUZBsGTGAXrAigFvg2VT23GI7IBceD8KYjkx8obMeAeeHAQ1otfGPYjGwh0Gg7U1yTZz3o3jMEkfIZLMMxV+MwjkFrhBn5qGTqwK6D0BeMqnKPgFHMadWrO0ry21ExeZQdk+mGipQmY5HPhLoiqDMt1h8AT4JVN4HAbh344CqtYP2SuQhblCOqFbhDdooZcndhmKJiHMjRbr0m41Fw1tItjO6if5zPYWSWxFYIvwJJQmdryH5Bn0+cd0zmPAAAAAElFTkSuQmCC"
                label="Сохранить видимую часть как PNG"
                value="page"/>

            <menuitem class="menuitem-iconic"
                image="data:image/png;charset=utf-8;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAABmJLR0QA/wD/AP+gvaeTAAACe0lEQVRYCc2Xv2sUQRTHZ2M0RgNq9M5gVLAxENBOIaRJmhiri2ChpLCy8h+wEsTGf8BK0EZJVBAF04hwoMFGSBDSxP9AohBMTJR4rJ8HzuXt7uwys3scHt/vvDdv3q/dmbu9NcbxieN4AN6DX+BP6IMfOL2CZxwp/U0kGISfYVl8I/CCb8Uo7UjwE2yzUPCB4Q1ch0UYZPEO7IeCDYZGFEVNpD8oPgT/QMEcQ6bBvGz4ij+ijW206Tx/a++xyj95DrkHCh5wBbEonvya8tvP/CVNXELmIt3AAeW5pnQf9bfDqR/ba5qYQjqRbsDpVNHYR7w0MWEcn240IGXtdpyXiWYnG2jpxA79CDY5qHuRbfS2terKM1JMGGP2QY3jTE5CwSiD/EZ8RGbBYWlAi5GsRzkLCW9Bi4bO0skt0HnT+ru0wc671YCtl5GVG+C+Xof1TGZPQ+UGqPMILtHEGDIYnWhAnhfDVG7GcXwVGQTvryHJD5H5LDwFT8BjsAZtjj70efxu8gx5jO4FG+zjvIDTOCyCPMge0sQmTbwocrRrIVsgT0obVySliftFDnotpIElHVigb7F2A3ohZAtmyHgaDsE6tGfgNrpcNcJsM1zh9i8iw8HeBf8UE/MLCjYYJl1VsY9Ai4b2CdkCHaf1FpMVeJErbyKD0Bvk7Xa+jPkTxeX2o4ahcgMUfh9WMundk5x2f/bfNbCl7kFN6VXVukqwqfSkyvekBku9mCQz7c7IF8HnULDDcHR31ZjEIeRAreEwj8MsvAaHmb9F7sAykD+g0wSOQ8FTanwXJZcUrPpySgonlrEezi2sF3AcgPb1vIVeFhK7SvBdeFDXsPpfv6YmkcwUIdAAAAAASUVORK5CYII="
                label="Сохранить выбранный элемент как PNG"
                value="click"/>

            <menuitem class="menuitem-iconic"
                image="data:image/png;charset=utf-8;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAABmJLR0QA/wD/AP+gvaeTAAABrklEQVRYCe2Xu0oDQRSGZ71HU2gkKmhjJQjaWdmk0nRpBR/BdxDEZ/ANFC+FKFiJYCHYiqW+gSSCeEViWL8DzmYyOyvLbkg14f/n/HP2zDkns0uyo5TjE4ZhEe7CR/gB0+CVoDM470iZ3kWCEryHWdFg4UraioEdyOJ9fJtQcMNwAV/gfyhxcRsWoOCNoRYEwTU2PSg+A3+g4JAh1mBSNmIlHhPhC1VNitf+Pi3+7BK2Hwr2+AahiJR8suJGmJ/SxDo2EXYDo0Zk3dBp5LcjqIDvnCbWsE7YDTiDcjqHWS9NVJTj04sGpKy+HcsyMdnNBlpmYoeewCcP6iA2wkCk8otjUlSUUkPQxDSTOShYZJDfiFtsHDwsNaixEI/I5iHhFtSomVm6eQvMvLa+sh163qsGdL2Y9Q34HfA74HfA74DfAb8D9g58Gv+XZUPnlVNGgndDd0peWcow08GkM1N7Rr4AnkBBk2GyfVWpjndCDiJ1Ao4IkKPZBnaW+SW2CbNAXkCrLFyFggNqPItIJAXzHk5J4cQd3vHEwuYFAotQH89b6KyQtQ8s3oFjZg2tfwH5w9EYtWehDwAAAABJRU5ErkJggg=="
                label="Сохранить выбранную область как PNG"
                value="clipping"/>
        </menugroup>
    `);
    var menugroup = df.firstChild;
    menugroup.setAttribute("context", "");
    menugroup.handleCommand = e => {
        var name = _id + ":DataURLReady";
        main = main.replace("%MESSAGE_NAME%", name);

        var urls = {}, configurable = true, enumerable = true;
        Object.entries(parts).forEach(([key, part]) => Object.defineProperty(urls, key, {
            configurable, enumerable, get() {
                var value = `data:;charset=utf-8,({${
                    encodeURIComponent(main + part)
                }%0A}).init("${key}")`;
                Object.defineProperty(urls, key, {configurable, enumerable, value});
                return value;
        }}));
        var getTabLabel = () => {
            var label = gBrowser.selectedTab.label;
            var label = label.replace(/[:+.\\\/<>?*|"]+/g, " ").replace(/\s\s+/g, " ");
            return label.substring(0, 50);
        }
        var listener = msg => {
            var fp = makeFilePicker();
            fp.init(window.browsingContext, "Сохранить как…", fp.modeSave);
            fp.appendFilter("", "*.png");
            fp.defaultString = getTabLabel() + ".png";
            fp.open(res => {
                if (res == fp.returnCancel || !fp.file) return;
                var wbp = makeWebBrowserPersist(), args = [
                    Services.io.newURI(msg.data), document.nodePrincipal,
                    null, null, null, null, fp.file, null
                ];
                //wbp.saveURI.length == 9 && splice(args);
                var {length} = wbp.saveURI;
                length >= 9 && splice(args);
                length == 10 && args.splice(3, 0, null);
                wbp.saveURI(...args);
            });
        }
        var splice = arr => {
            var fox74 = parseInt(Services.appinfo.platformVersion) >= 74;
            var args = [fox74 ? 7 : 2, 0, fox74 ? Ci.nsIContentPolicy.TYPE_IMAGE : null];
            (splice = arr => arr.splice(...args))(arr);
        }
        messageManager.addMessageListener(name, listener);
        addDestructor(() => messageManager.removeMessageListener(name, listener));

        (menugroup.handleCommand = e => gBrowser.selectedBrowser.messageManager
            .loadFrameScript(urls[e.target.value], false)
        )(e);
    }
    menugroup.addEventListener("command", e => menugroup.handleCommand(e));
    menuPopup.querySelector('menuitem[label*="ярлык"]').after(df);
})(`
    init(cmd) {
        cmd.startsWith("c")
            ? this[cmd].init(this[cmd].parent = this)
            : this[cmd]();
    },
    capture(win, x, y, width, height) {
        var canvas = win.document.createElementNS("${xhtmlns}", "canvas");
        canvas.width = width;
        canvas.height = height;
        var ctx = canvas.getContext("2d");
        var tryDraw = ind => {
            try {ctx.drawWindow(win, x, y, canvas.width, canvas.height, "white")}
            catch(ex) {canvas.height = ind * canvas.width; tryDraw(--ind);}
        }
        tryDraw(17);
        sendAsyncMessage("%MESSAGE_NAME%", canvas.toDataURL("image/png"));
    },
    `, {

    all: `all() {
        var win = content;
        this.capture(win, 0, 0, win.innerWidth + win.scrollMaxX, win.innerHeight + win.scrollMaxY);
    }`,
    page: `page() {
        var win = content, doc = win.document, body = doc.body, html = doc.documentElement;
        var scrX = (body.scrollLeft || html.scrollLeft) - html.clientLeft;
        var scrY = (body.scrollTop || html.scrollTop) - html.clientTop;
        this.capture(win, scrX, scrY, win.innerWidth, win.innerHeight);
    }`,
    clipping: `clipping: {
        handleEvent(e) {
            if (e.button) return false;
            e.preventDefault();
            e.stopPropagation();
            switch(e.type) {
                case "mousedown":
                    this.downX = e.pageX;
                    this.downY = e.pageY;
                    this.bs.left = this.downX + "px";
                    this.bs.top = this.downY + "px";
                    this.body.appendChild(this.box);
                    this.flag = true;
                    break;
                case "mousemove":
                    if (!this.flag) return;
                    this.moveX = e.pageX;
                    this.moveY = e.pageY;
                    if (this.downX > this.moveX) this.bs.left = this.moveX + "px";
                    if (this.downY > this.moveY) this.bs.top    = this.moveY + "px";
                    this.bs.width = Math.abs(this.moveX - this.downX) + "px";
                    this.bs.height = Math.abs(this.moveY - this.downY) + "px";
                    break;
                case "mouseup":
                    this.uninit();
                    break;
            }
        },
        init() {
            var win = {};
            Cc["@mozilla.org/focus-manager;1"].getService(Ci.nsIFocusManager)
                .getFocusedElementForWindow(content, true, win);
            this.win = win.value;

            this.doc = this.win.document;
            this.body = this.doc.body;
            if (!HTMLBodyElement.isInstance(this.body)) {
                Cc["@mozilla.org/alerts-service;1"].getService(Ci.nsIAlertsService)
                    .showAlertNotification("${self.image}", ${JSON.stringify(self.label)}, "Не удается захватить!");
                return false;
            }
            this.flag = null;
            this.box = this.doc.createElement("div");
            this.bs = this.box.style;
            this.bs.border = "#0f0 dashed 2px";
            this.bs.position = "absolute";
            this.bs.zIndex = "2147483647";
            this.defaultCursor = this.win.getComputedStyle(this.body, "").cursor;
            this.body.style.cursor = "crosshair";
            ["click", "mouseup", "mousemove", "mousedown"].forEach(type=> this.doc.addEventListener(type, this, true));
        },
        uninit() {
            var pos = [this.win, parseInt(this.bs.left), parseInt(this.bs.top), parseInt(this.bs.width), parseInt(this.bs.height)];
            this.body.style.cursor = this.defaultCursor;
            this.body.removeChild(this.box);
            this.parent.capture.apply(this, pos);
            ["click", "mouseup", "mousemove", "mousedown"].forEach(type=> this.doc.removeEventListener(type, this, true));
        }
    }`,
    click: `click: {
        getPosition() {
            var html = this.doc.documentElement;
            var body = this.doc.body;
            var rect = this.target.getBoundingClientRect();
            return [
                this.win,
                Math.round(rect.left) + (body.scrollLeft || html.scrollLeft) - html.clientLeft,
                Math.round(rect.top) + (body.scrollTop || html.scrollTop) - html.clientTop,
                parseInt(rect.width),
                parseInt(rect.height)
            ];
        },
        highlight() {
            this.orgStyle = this.target.hasAttribute("style") ? this.target.style.cssText : false;
            this.target.style.cssText += "outline: red 2px solid; outline-offset: 2px; -moz-outline-radius: 2px;";
        },
        lowlight() {
            if (this.orgStyle) this.target.style.cssText = this.orgStyle;
            else this.target.removeAttribute("style");
        },
        handleEvent(e) {
            switch(e.type){
                case "click":
                    if (e.button) return;
                    e.preventDefault();
                    e.stopPropagation();
                    this.lowlight();
                    this.parent.capture.apply(this, this.getPosition());
                    this.uninit();
                    break;
                case "mouseover":
                    if (this.target) this.lowlight();
                    this.target = e.target;
                    this.highlight();
                    break;
            }
        },
        init() {
            this.win = content;
            this.doc = content.document;
            ["click", "mouseover"].forEach(type=> this.doc.addEventListener(type, this, true));
        },
        uninit() {
            this.target = false;
            ["click", "mouseover"].forEach(type=> this.doc.removeEventListener(type, this, true));
        }
    }`
});
